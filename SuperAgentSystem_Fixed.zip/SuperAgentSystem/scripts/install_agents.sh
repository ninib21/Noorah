#!/bin/bash
echo "Installing SuperAgentSystem..."
mkdir -p agents config docs scripts
echo "System installed. Add PRD and BMAD files to get started."
